@echo off
cd /d "%~dp0"
dotnet run --project FeltetelTesztek.csproj -c Release
pause
