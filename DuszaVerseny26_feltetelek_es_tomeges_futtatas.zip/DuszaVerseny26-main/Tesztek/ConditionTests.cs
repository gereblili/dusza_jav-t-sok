using System;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
using Terminal.Gui;
namespace DuszaVerseny26
{
    class ConditionTests
    {
        static int checks;
        static void Check(bool ok, string message) { checks++; if (!ok) throw new Exception(message); }
        static void Run(string code, string expected, string error)
        {
            string dir = Path.Combine(Path.GetTempPath(), "robot_condition_tests");
            Directory.CreateDirectory(dir);
            string input = Path.Combine(dir, "input.txt");
            File.WriteAllText(input, "1 1\n>\n" + code);
            Program.Beolvadas(new string[] { "-q", input, Path.Combine(dir,"output.txt") });
            for (int repeat = 0; repeat < 2; repeat++)
            {
                if (repeat == 1) Program.parancsok = new List<string>(new BlokkProgram(Program.parancsok).forras);
                Motor.ProgramFuttatas();
                Check(string.Join(",", Robot.konzol) == expected, code + " console: " + string.Join(",", Robot.konzol));
                Check(Robot.hiba == error, code + " error: " + Robot.hiba);
            }
        }
        static bool Accept(MainLoop loop)
        {
            Application.RequestStop();
            return false;
        }
        static void Main()
        {
            string[] ops = { "<", "<=", ">", ">=", "=", "<>" };
            bool[,] results = { {true,false,false}, {true,true,false}, {false,false,true}, {false,true,true}, {false,true,false}, {true,false,true} };
            for (int op = 0; op < ops.Length; op++)
                for (int x = 4; x <= 6; x++)
                    for (int space = 0; space < 2; space++)
                    {
                        string gap = space == 0 ? "" : " ";
                        Run("set x to " + x + "\nif x" + gap + ops[op] + gap + "5\n    print 1\nelse\n    print 0\n", results[op,x-4] ? "1" : "0", "");
                    }
            Run("set x to 2\nwhile x<5\n    print x\n    set x to x + 1\nprint x\n", "2,3,4,5", "");
            Run("set x to 5\nwhile x<5\n    print 0\nprint x\n", "5", "");
            Run("set x to 4\nwhile x<=5\n    print x\n    set x to x + 1\n", "4,5", "");
            Run("set x to 0\nwhile x<2\n    set y to 0\n    while y<2\n        print y\n        set y to y + 1\n    set x to x + 1\n", "0,1,0,1", "");
            string[] bools = { "false", "true" };
            for (int a = 0; a < 2; a++) for (int b = 0; b < 2; b++)
            {
                string prefix = "set a to " + bools[a] + "\nset b to " + bools[b] + "\n";
                Run(prefix + "if a and b\n    print 1\nelse\n    print 0\n", a == 1 && b == 1 ? "1" : "0", "");
                Run(prefix + "if a or b\n    print 1\nelse\n    print 0\n", a == 1 || b == 1 ? "1" : "0", "");
            }
            Run("set a to true\nset b to true\nwhile a and b\n    print 1\n    set b to false\nprint 2\n", "1,2", "");
            Run("set a to false\nwhile not a\n    print 1\n    set a to true\n", "1", "");
            Application.Init(new FakeDriver());
            try
            {
                string[] conditions = { "x<5", "x <= 5", "a and b", "not a" };
                string[] types = { "if", "if-else", "while" };
                foreach (string type in types) foreach (string condition in conditions)
                {
                    string source = (type == "while" ? "while " : "if ") + condition;
                    BlokkAblak dialog = new BlokkAblak(type,source,false,false);
                    TextField field = (TextField)typeof(BlokkAblak).GetField("elso",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(dialog);
                    Check(field.Text.ToString() == condition,"condition truncated");
                    Application.MainLoop.AddTimeout(TimeSpan.FromMilliseconds(10), delegate(MainLoop loop)
                    {
                        typeof(BlokkAblak).GetMethod("Elfogad",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(dialog,null);
                        return false;
                    });
                    dialog.Megnyit();
                    Check(dialog.elfogadva && dialog.sor == source,"dialog save");
                }
            }
            finally { Application.Shutdown(); }
            Console.WriteLine(checks + " condition and dialog checks passed");
        }
    }
}
