using System;
using System.IO;
using System.Collections.Generic;
namespace DuszaVerseny26
{
    class BatchTests
    {
        static int runs;
        static void Check(string actual, string expected, string what)
        {
            if(actual.Replace("\r\n","\n").TrimEnd('\n')!=expected.Replace("\r\n","\n").TrimEnd('\n'))
                throw new Exception(what+"\nEXPECTED:\n"+expected+"\nACTUAL:\n"+actual);
        }
        static void Verify(string input,string output)
        {
            Motor.ProgramFuttatas();
            Check(File.ReadAllText(output),File.ReadAllText(Path.ChangeExtension(input,"expected")),input+" log");
            string state=Robot.hiba+"\n"+Robot.sor+"\n"+Robot.oszlop+"\n"+Robot.Irany+"\n"+Robot.arany+"\n"+string.Join("\n",Robot.konzol);
            Check(state,File.ReadAllText(Path.ChangeExtension(input,"state")),input+" state");
            runs++;
        }
        static void Main()
        {
            string dir=Directory.GetCurrentDirectory()+Path.DirectorySeparatorChar;
            string[] files=Directory.GetFiles(dir+"cases","*.txt");Array.Sort(files);
            foreach(string input in files)
            {
                string output=dir+"batch_output.txt";
                Program.Beolvadas(new string[]{"-q",input,output});
                Verify(input,output);
                // A GUI blokkokon keresztüli újragenerálása és ismételt futtatás.
                BlokkProgram blocks=new BlokkProgram(Program.parancsok);
                Program.parancsok=new List<string>(blocks.forras);
                Verify(input,output);
            }
            Console.WriteLine(files.Length+" cases; "+runs+" executions, exact logs and robot/console state passed.");
        }
    }
}
