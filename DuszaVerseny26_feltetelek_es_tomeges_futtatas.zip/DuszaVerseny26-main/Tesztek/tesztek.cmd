@echo off
cd /d "%~dp0"
dotnet run --project Tesztek.csproj -c Release
pause
