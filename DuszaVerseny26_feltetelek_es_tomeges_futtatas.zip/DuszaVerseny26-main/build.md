# Fordítás és indítás

A javítást Linux alatt, .NET SDK 8.0.408-cal fordítottuk. A GUI Terminal.Gui 1.17.1-et használ. A Windows EXE .NET Framework 4.7.2-t céloz; Windows alatt ezt a keretrendszert igényli. Az EXE és minden szükséges csomag-DLL a `Futtathato_Windows` mappában található. Natív Windows-futtatás még szükséges a csapat gépén.

## .NET 8

A `Robotszimulator_TerminalGui` könyvtárban:

```sh
dotnet build Robotszimulator_net8.csproj -c Release
dotnet run --project Robotszimulator_net8.csproj -- pelda.txt output.txt
dotnet run --project Robotszimulator_net8.csproj -- -q pelda.txt output.txt
```

## Windows / .NET Framework

```sh
dotnet build Robotszimulator_TerminalGui/DuszaVerseny26.sln -c Release
```

A mellékelt EXE a fenti fordítás kimenetéből származik. A `Futtathato_Windows/inditas.cmd` az ott mellékelt példával indít. Egyéb bemenethez:

```bat
DuszaVerseny26.exe input_001.txt output_001.txt
DuszaVerseny26.exe -q input_001.txt output_001.txt
```

Ajánlott terminálméret: 120 × 44 karakter. A forrás nem tartalmaz `var`, `break`, `BigInteger` vagy külön `FutasiHiba` osztályt. Számtartomány: `int`; részletes korlátok a `JAVITASOK_ES_TESZTEK.txt` fájlban.

## Tömeges futtatás

A gyökérben található `osszes_input_futtatasa.cmd` az `inputok` mappa minden .txt fájlját lefuttatja, külön naplókkal a `naplok` mappába. .NET Framework 4.7.2 szükséges.

.NET 8 esetén:
```sh
dotnet run --project Robotszimulator_TerminalGui/Robotszimulator_net8.csproj -- --batch inputok naplok
```
