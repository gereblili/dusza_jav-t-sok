# AI-használat – a csapat által véglegesítendő vázlat

Eszköz: ChatGPT / Codex. A jelenlegi munkamenet modellcsaládja GPT-6; a teljes fejlesztés során használt további modelleket és pontos felületi verzióneveket a csapat egészítse ki. A program AI-val készült részének becsült aránya: **a csapat töltse ki**; ezt a teljes munkátok ismerete nélkül nem lehet megbízhatóan megadni.

Az AI az átadott C#-kód hibajavításában, a naplózás bekötésében, a Terminal.Gui-felületben, a blokkszerkesztésben és az ellenőrzésben segített. A javításokban megmaradt a csapat kétdimenziós térképe és több eredeti elnevezése. A jelenlegi ellenőrzések eredményeit a JAVITASOK_ES_TESZTEK.txt tartalmazza. A közvetlen feltételeket és a kötegelt futtatást a felhasználó kérésére bővítettük. Az eredményeket a csapatnak is ellenőriznie és megértenie kell; natív Windows-próba és a hivatalos tesztek még szükségesek.

Öt konkrét eset:

1. A sor és oszlop felcserélése hibás mozgást okozott. A javítás a saját `barlang[,]` tömb megtartásával történt.
2. A betöltött térkép közvetlen módosítása elrontotta az újraindítást. A robot külön másolatot kapott, ismételt futást is teszteltünk.
3. A naplózás hiányos volt. A `Naplozas.cs` osztályt összekötöttük a végrehajtással és a felülettel, majd a naplókat az elvárt teljes szöveggel vetettük össze.
4. A beküldött `Motor` külön végrehajtási osztályának ötletét beépítettük. Az `else` és a fájl végén álló ciklus hibáit javítottuk, a motor léptethető is lett.
5. A követelményaudit feltárta a kézi vezérlés hiányát és az `int` korlátját. A kézi vezérlés elkészült; a számtartomány korlátját dokumentáltuk, nem állítottunk feltétel nélküli teljes megfelelést.
