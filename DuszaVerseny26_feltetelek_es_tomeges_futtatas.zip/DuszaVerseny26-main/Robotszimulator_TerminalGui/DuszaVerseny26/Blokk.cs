using System;
using System.Collections.Generic;

namespace DuszaVerseny26
{
    internal class Blokk
    {
        public string tipus;
        public string szoveg;
        public List<Blokk> torzs = new List<Blokk>();
        public List<Blokk> masikAg = new List<Blokk>();
        public Blokk(string fajta, string sor)
        {
            tipus = fajta;
            szoveg = sor;
        }
        public bool Vezerlo() => tipus == "if" || tipus == "if-else" || tipus == "while";
        public static bool EgyszeruErtek(string szoveg)
        {
            if (szoveg == "true" || szoveg == "false" || Robot.JoNev(szoveg))
                return true;
            if (szoveg.Length == 0) 
                return false;
            for (int i = 0; i < szoveg.Length; i++)
            {
                if (szoveg[i] < '0' || szoveg[i] > '9')
                    return false;
            }
            int szam = 0;
            return int.TryParse(szoveg, out szam) && szam >= 0 && szam <= 100;
        }

    }
    internal class BlokkSor
    {
        public Blokk blokk;
        public List<Blokk> lista;
        public int melyseg;
        public bool elseSor;
    }
    internal class BlokkProgram
    {
        public List<Blokk> blokkok = new List<Blokk>();
        public List<string> forras = new List<string>();
        public List<BlokkSor> sorok = new List<BlokkSor>();
        public string hiba = "";
        public BlokkProgram(List<string> eredeti)
        {
            int i = 0;
            if (eredeti.Count > 0)
                blokkok = Beolvas(eredeti, ref i, Behuzas(eredeti[0]));
            Frissit();
        }
        static int Behuzas(string sor)
        {
            int db = 0;
            while (db < sor.Length && sor[db] == ' ')
                db++;
            return db;
        }
        List<Blokk> Beolvas(List<string> szoveg, ref int i, int szint)
        {
            List<Blokk> lista = new List<Blokk>();
            while (i < szoveg.Count && Behuzas(szoveg[i]) == szint && szoveg[i].TrimStart() != "else")
            {
                string sor = szoveg[i].TrimStart();
                string[] p = sor.Split(' ');
                Blokk b = new Blokk(p[0], sor);
                i++;
                if (b.Vezerlo() && i < szoveg.Count && Behuzas(szoveg[i]) > szint)
                    b.torzs = Beolvas(szoveg, ref i, Behuzas(szoveg[i]));

                if (b.tipus == "if" && i < szoveg.Count && Behuzas(szoveg[i]) == szint && szoveg[i].TrimStart() == "else")
                {
                    b.tipus = "if-else";
                    i++;
                    if (i < szoveg.Count && Behuzas(szoveg[i]) > szint)
                        b.masikAg = Beolvas(szoveg, ref i, Behuzas(szoveg[i]));
                }
                lista.Add(b);
            }
            return lista;
        }
        public void Frissit()
        {
            forras.Clear();
            sorok.Clear();
            KiirLista(blokkok, 0);
        }
        void KiirLista(List<Blokk> lista, int melyseg)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                Blokk b = lista[i];
                SorHozzaad(b, lista, melyseg, false, b.szoveg);
                if (b.Vezerlo()) KiirLista(b.torzs, melyseg + 1);
                if (b.tipus == "if-else")
                {
                    SorHozzaad(b, lista, melyseg, true, "else");
                    KiirLista(b.masikAg, melyseg + 1);
                }
            }
        }
        void SorHozzaad(Blokk b, List<Blokk> lista, int melyseg, bool masik, string szoveg)
        {
            forras.Add(new string(' ', melyseg * 2) + szoveg);
            BlokkSor adat = new BlokkSor();
            adat.blokk = b;
            adat.lista = lista;
            adat.melyseg = melyseg;
            adat.elseSor = masik;
            sorok.Add(adat);
        }
        // hely:
        // 0 = elé
        // 1 = mögé
        // 2 = törzsbe
        // 3 = else ágba
        // 4 = program végére

        public bool Beszur(Blokk uj, int kijelolt, int hely)
        {
            hiba = "";
            List<Blokk> cel = blokkok;
            int index = cel.Count;
            int melyseg = 0;
            if (hely != 4 && sorok.Count > 0)
            {
                if (kijelolt < 0 || kijelolt >= sorok.Count)
                {
                    hiba = "Előbb jelölj ki egy blokkot!";
                    return false;
                }

                BlokkSor sor = sorok[kijelolt];
                cel = sor.lista;
                melyseg = sor.melyseg;
                index = cel.IndexOf(sor.blokk);
                if (hely == 1) index++;
                else if (hely == 2)
                {
                    if (!sor.blokk.Vezerlo())
                    {
                        hiba = "Csak if vagy while blokknak van törzse.";
                        return false;
                    }
                    cel = sor.blokk.torzs;
                    if (sor.elseSor)
                        cel = sor.blokk.masikAg;
                    index = cel.Count;
                    melyseg++;
                }

                else if (hely == 3)
                {
                    if (sor.blokk.tipus != "if-else")
                    {
                        hiba = "Ennek a blokknak nincs else ága.";
                        return false;
                    }

                    cel = sor.blokk.masikAg;
                    index = cel.Count;
                    melyseg++;
                }
            }
            else if (sorok.Count == 0 && (hely == 2 || hely == 3))
            {
                hiba = "Üres programban először hozz létre egy vezérlőblokkot!";
                return false;
            }

            if (uj.Vezerlo() && melyseg >= 3)
            {
                hiba = "Legfeljebb három egymásba ágyazott vezérlőblokk lehet.";
                return false;
            }
            cel.Insert(index, uj);
            Frissit();
            return true;
        }
        public void Modosit(int kijelolt, string ujSor)
        {
            sorok[kijelolt].blokk.szoveg = ujSor;
            Frissit();
        }
        public void Torol(int kijelolt)
        {
            BlokkSor sor = sorok[kijelolt];
            sor.lista.Remove(sor.blokk);
            Frissit();
        }
    }
}