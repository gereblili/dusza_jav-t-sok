using System;
using Terminal.Gui;

namespace DuszaVerseny26
{
    internal class BlokkAblak
    {
        Dialog ablak;
        TextField nev;
        TextField elso;
        TextField masodik;
        ListView muveletLista;
        RadioGroup helyLista;
        string tipus;
        bool ujBlokk;
        string[] muveletek = { "érték", "isThere", "not", "+", "-", "*", "=", "<>", "<", "<=", ">", ">=", "and", "or" };
        public bool elfogadva = false;
        public string sor = "";
        public int hely = 4;

        public BlokkAblak(string fajta, string regiSor, bool uj, bool uresProgram)
        {
            tipus = fajta;
            ujBlokk = uj;
            string cim = "Blokk módosítása: " + tipus;
            if (uj) cim = "Új blokk: " + tipus;
            ablak = new Dialog(cim, 74, 28);
            int y = 0;
            nev = new TextField("x");
            elso = new TextField("1");
            masodik = new TextField("1");
            if (tipus == "if" || tipus == "if-else" || tipus == "while") elso.Text = "true";
            if (tipus == "set")
            {
                Mezo("Változónév:", nev, y);
                y += 2;
            }
            if (tipus != "mine")
            {
                string cimke = "Érték / változónév:";
                if (tipus == "if" || tipus == "if-else" || tipus == "while") cimke = "Feltétel:";
                if (tipus == "step") cimke = "Lépések száma:";
                if (tipus == "turn") cimke = "Bal negyedfordulatok:";
                Mezo(cimke, elso, y);
                y += 2;
            }
            if (tipus == "set")
            {
                Label cimke = new Label("Művelet (nyilakkal választható):");
                cimke.Y = y;
                ablak.Add(cimke);
                y++;
                muveletLista = new ListView(muveletek);
                muveletLista.Y = y;
                muveletLista.Width = Dim.Fill(2);
                muveletLista.Height = 4;
                ablak.Add(muveletLista);
                y += 5;
                Mezo("Második érték:", masodik, y);
                y += 2;
                Label megjegyzes = new Label("A második érték csak kétoperandusú művelethez kell.");
                megjegyzes.Y = y;
                ablak.Add(megjegyzes);
                y += 2;
            }
            if (tipus == "if" || tipus == "if-else" || tipus == "while")
            {
                Label pelda = new Label("Példák: x<5, x <= 5, a and b, not a");
                pelda.Y = y;
                ablak.Add(pelda);
                y += 2;
            }
            if (tipus == "mine")
            {
                Label nincs = new Label("mine here – nincs beállítandó paraméter.");
                ablak.Add(nincs);
                y = 2;
            }
            if (uj)
            {
                Label cimke = new Label("Beszúrás helye:");
                cimke.Y = y;
                ablak.Add(cimke);
                helyLista = new RadioGroup(new NStack.ustring[]
                { "Kijelölt blokk elé", "Kijelölt blokk mögé", "Kijelölt blokk törzsének végére", "Kijelölt if-else else ágának végére", "Program végére" });
                helyLista.Y = y + 1;
                if (uresProgram)
                    helyLista.SelectedItem = 4;
                else
                    helyLista.SelectedItem = 1;
                ablak.Add(helyLista);
            }
            if (!uj) RegiAdatok(regiSor);
            Button mentes = new Button("Rendben");
            mentes.Clicked += Elfogad;
            Button megsem = new Button("Mégsem");
            megsem.Clicked += Megsem;
            ablak.AddButton(mentes);
            ablak.AddButton(megsem);
        }

        void Mezo(string cim, TextField mezo, int y)
        {
            Label felirat = new Label(cim);
            felirat.Y = y;
            mezo.X = 25;
            mezo.Y = y;
            mezo.Width = Dim.Fill(2);
            ablak.Add(felirat, mezo);
        }

        void RegiAdatok(string regiSor)
        {
            string[] p = regiSor.Split(' ');
            if (tipus == "step" || tipus == "turn")
                elso.Text = p[2];
            else if (tipus == "print")
                elso.Text = p[1];
            else if (tipus == "if" || tipus == "if-else" || tipus == "while")
                // A feltétel összes szavát megtartjuk szerkesztéskor.
                elso.Text = regiSor.Substring(regiSor.IndexOf(' ') + 1).Trim();
            else if (tipus == "set")
            {
                nev.Text = p[1];
                string muvelet = "érték";
                if (p.Length == 4) elso.Text = p[3];
                else if (p.Length == 5)
                {
                    muvelet = p[3];
                    elso.Text = p[4];
                }
                else
                {
                    elso.Text = p[3];
                    muvelet = p[4];
                    masodik.Text = p[5];
                }
                for (int i = 0; i < muveletek.Length; i++)
                    if (muveletek[i] == muvelet) muveletLista.SelectedItem = i;
                muveletLista.EnsureSelectedItemVisible();
            }
        }

        void Elfogad()
        {
            string a = elso.Text.ToString().Trim();
            string b = masodik.Text.ToString().Trim();
            string n = nev.Text.ToString().Trim();
            bool felteteles = tipus == "if" || tipus == "if-else" || tipus == "while";
            if (tipus != "mine" && !felteteles && !Blokk.EgyszeruErtek(a))
            {
                MessageBox.ErrorQuery("Hibás érték", "0–100 közötti egész, true/false vagy érvényes változónév szükséges.", "Rendben");
                return;
            }
            if (tipus == "set")
            {
                if (!Robot.JoNev(n))
                {
                    MessageBox.ErrorQuery("Hibás név", "A név betűvel kezdődjön, csak betűt és számot tartalmazzon, és ne legyen kulcsszó!", "Rendben");
                    return;
                }
                int index = muveletLista.SelectedItem;
                if (index >= 3 && !Blokk.EgyszeruErtek(b))
                {
                    MessageBox.ErrorQuery("Hibás második érték", "A második érték is szám, logikai érték vagy változónév legyen!", "Rendben");
                    return;
                }
                string kifejezes = a;
                if (index == 1 || index == 2) kifejezes = muveletek[index] + " " + a;
                else if (index >= 3) kifejezes = a + " " + muveletek[index] + " " + b;
                sor = "set " + n + " to " + kifejezes;
            }
            else if (tipus == "step") sor = "step forward " + a;
            else if (tipus == "turn") sor = "turn by " + a;
            else if (tipus == "mine") sor = "mine here";
            else if (tipus == "print") sor = "print " + a;
            else if (tipus == "while") sor = "while " + a;
            else sor = "if " + a;
            if (ujBlokk) hely = helyLista.SelectedItem;
            elfogadva = true;
            Application.RequestStop();
        }

        void Megsem() { Application.RequestStop(); }
        public void Megnyit()
        {
            Application.Run(ablak);
            ablak.Dispose();
        }
    }
}
