
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Terminal.Gui;

namespace DuszaVerseny26
{
    internal class Felulet
    {
        BlokkProgram szerkeszto;
        Window ablak;
        FrameView bal;
        FrameView paletta;
        ListView tipusLista;
        ListView kod;
        TextView valtozok;
        TextView konzol;
        TextView naplo;
        Label szenzor;
        Label arany;
        Label allapot;
        TerkepNezet terkep;
        Button futtat;
        Button kovetkezo;
        Button szunet;
        Button forrasGomb;
        Button blokkGomb;
        ColorScheme aktivSzin;
        bool blokkNezet;
        bool indult;
        bool automatikus;
        object idozito;
        string[] tipusok = { "step", "turn", "mine", "print", "set", "if", "if-else", "while" };

        public Felulet() => szerkeszto = new BlokkProgram(Program.parancsok);

        public void Indit()
        {
            Application.UseSystemConsole = true;
            Application.Init();
            try
            {
                Letrehoz();
                Alaphelyzet();
                Application.Run();
            }
            finally
            {
                IdozitoLeallit();
                Program.Bezar();
                Application.Shutdown();
            }
        }

        void Letrehoz()
        {
            ColorScheme szin = new ColorScheme();
            szin.Normal = Terminal.Gui.Attribute.Make(Color.Gray, Color.Black);
            szin.Focus = Terminal.Gui.Attribute.Make(Color.Black, Color.BrightMagenta);
            szin.HotNormal = szin.Normal;
            szin.HotFocus = szin.Focus;
            szin.Disabled = Terminal.Gui.Attribute.Make(Color.DarkGray, Color.Black);
            Colors.Base = szin;
            Colors.Dialog = szin;
            Colors.Menu = szin;
            Colors.Error = szin;
            Colors.TopLevel = szin;
            aktivSzin = new ColorScheme();
            aktivSzin.Normal = Terminal.Gui.Attribute.Make(Color.BrightMagenta, Color.Black);
            aktivSzin.Focus = szin.Focus;
            aktivSzin.HotNormal = aktivSzin.Normal;
            aktivSzin.HotFocus = szin.HotFocus;
            ColorScheme cimSzin = new ColorScheme();
            cimSzin.Normal = Terminal.Gui.Attribute.Make(Color.BrightMagenta, Color.Black);
            cimSzin.Focus = cimSzin.Normal;
            cimSzin.HotNormal = cimSzin.Normal;
            cimSzin.HotFocus = cimSzin.Normal;
            cimSzin.Disabled = cimSzin.Normal;
            ablak = new Window("ROBOTSZIMULÁTOR – EBNYELVŰEK");
            ablak.ColorScheme = cimSzin;
            ablak.Border.BorderBrush = Color.White;

            futtat = new Button("Futtatás");
            futtat.X = 1; futtat.Y = 0;
            futtat.Clicked += Futtatas;
            szunet = new Button("Szünet");
            szunet.X = Pos.Right(futtat) + 1; szunet.Y = 0;
            szunet.Clicked += Szunet;
            kovetkezo = new Button("Következő");
            kovetkezo.Y = 0;
            kovetkezo.Clicked += Kovetkezo;
            Button alap = new Button("Alaphelyzet");
            alap.X = Pos.Right(szunet) + 1; alap.Y = 0;
            kovetkezo.X = Pos.Right(alap) + 1;
            alap.Clicked += Alaphelyzet;

            Button kezi = new Button("Kézi vezérlés");
            kezi.X = Pos.Right(kovetkezo) + 1; kezi.Y = 0; kezi.Clicked += KeziVezerles;

            bal = new LilaKeret("KÓD");
            bal.ColorScheme = cimSzin;
            bal.Border.BorderBrush = Color.White;
            bal.Y = 2; bal.Width = Dim.Percent(55); bal.Height = Dim.Fill(7);
            forrasGomb = new Button("Forráskód");
            forrasGomb.Clicked += Forras;
            blokkGomb = new Button("Blokkok");
            blokkGomb.X = Pos.Right(forrasGomb) + 1;
            blokkGomb.Clicked += Blokkok;
            Button ment = new Button("Mentés");
            ment.X = Pos.Right(blokkGomb) + 1;
            ment.Clicked += Mentes;

            paletta = new LilaKeret("Új blokk");
            paletta.ColorScheme = cimSzin;
            paletta.Border.BorderBrush = Color.White;
            paletta.Y = 2; paletta.Width = 21; paletta.Height = Dim.Fill(6);
            tipusLista = new ListView(new string[] { "Lépés", "Fordulás", "Bányászás", "Kiírás", "Értékadás", "Ha", "Ha–különben", "Amíg" });
            tipusLista.Width = Dim.Fill(); tipusLista.Height = 8;
            Button beszur = new Button("Beszúr");
            beszur.Y = 9; beszur.Clicked += Beszuras;
            Button modosit = new Button("Módosít");
            modosit.Y = 11; modosit.Clicked += Modositas;
            Button torol = new Button("Töröl");
            torol.Y = 13; torol.Clicked += Torles;
            paletta.Add(tipusLista, beszur, modosit, torol);
            kod = new ListView();
            kod.ColorScheme = szin;
            kod.Y = 2; kod.Width = Dim.Fill(); kod.Height = Dim.Fill(6);
            FrameView valtozoKeret = new LilaKeret("Változók: név | típus | érték");
            valtozoKeret.ColorScheme = cimSzin;
            valtozoKeret.Border.BorderBrush = Color.White;
            valtozoKeret.Y = Pos.AnchorEnd(5); valtozoKeret.Height = 5; valtozoKeret.Width = Dim.Fill();
            valtozok = SzovegNezet();
            valtozoKeret.Add(valtozok);
            bal.Add(forrasGomb, blokkGomb, ment, paletta, kod, valtozoKeret);
            FrameView banya = new LilaKeret("BÁNYA");
            banya.ColorScheme = cimSzin;
            banya.Border.BorderBrush = Color.White;
            banya.X = Pos.Right(bal) + 1; banya.Width = Dim.Fill(); banya.Y = 2; banya.Height = Dim.Percent(60);
            ScrollView gorgeto = new ScrollView();
            gorgeto.Width = Dim.Fill(); gorgeto.Height = Dim.Fill(8);
            gorgeto.ContentSize = new Size(Program.col * 2, Program.row);
            gorgeto.ShowVerticalScrollIndicator = true;
            gorgeto.ShowHorizontalScrollIndicator = true;
            terkep = new TerkepNezet();
            terkep.Width = Program.col * 2; terkep.Height = Program.row;
            gorgeto.Add(terkep);
            FrameView jelKeret = new LilaKeret("Jelek magyarázata");
            jelKeret.Y = Pos.AnchorEnd(7); jelKeret.Height = 7; jelKeret.Width = Dim.Fill();
            jelKeret.ColorScheme = cimSzin;
            jelKeret.Border.BorderBrush = Color.White;
            Label magyarazat = new Label("@ arany  # fal  . üres\n? ismeretlen   > < ^ v robot");
            magyarazat.Y = 0; magyarazat.Height = 2; magyarazat.Width = Dim.Fill();
            szenzor = new Label(""); szenzor.Y = 2; szenzor.Width = Dim.Fill();
            arany = new Label(""); arany.Y = 3; arany.Width = Dim.Fill();
            jelKeret.Add(magyarazat, szenzor, arany);
            banya.Add(gorgeto, jelKeret);

            FrameView konzolKeret = new LilaKeret("KONZOL");
            konzolKeret.X = 0; konzolKeret.Y = Pos.Bottom(bal);
            konzolKeret.Width = Dim.Percent(55); konzolKeret.Height = 5;
            konzol = SzovegNezet();
            ColorScheme lila = new ColorScheme();
            lila.Normal = Terminal.Gui.Attribute.Make(Color.White, Color.Magenta);
            lila.Focus = lila.Normal;
            lila.HotNormal = lila.Normal;
            lila.HotFocus = lila.Normal;
            lila.Disabled = lila.Normal;
            konzolKeret.ColorScheme = cimSzin;
            konzolKeret.Border.BorderBrush = Color.White;
            konzol.ColorScheme = lila;
            konzolKeret.Add(konzol);
            FrameView naploKeret = new LilaKeret("NAPLÓ · " + Path.GetFileName(Program.outputfajl));
            naploKeret.X = Pos.Right(bal) + 1; naploKeret.Y = Pos.Bottom(banya);
            naploKeret.Width = Dim.Fill(); naploKeret.Height = Dim.Fill(3);
            naploKeret.ColorScheme = cimSzin;
            naploKeret.Border.BorderBrush = Color.White;
            naplo = SzovegNezet(); naploKeret.Add(naplo);

            Button kilep = new Button("Kilép");
            kilep.X = Pos.AnchorEnd(10); kilep.Y = Pos.AnchorEnd(2); kilep.Clicked += Kilepes;
            Button sugo = new Button("Súgó");
            sugo.X = Pos.AnchorEnd(21); sugo.Y = Pos.AnchorEnd(2); sugo.Clicked += Sugo;
            allapot = new Label("");
            allapot.Y = Pos.AnchorEnd(1); allapot.Width = Dim.Fill();
            // A címek színe nem öröklődik a gombokra és a listák szövegére.
            View[] normal = { futtat, szunet, alap, kovetkezo, kezi, ment,
                tipusLista, beszur, modosit, torol, magyarazat, szenzor, arany,
                kilep, sugo, allapot };
            for (int i = 0; i < normal.Length; i++) normal[i].ColorScheme = szin;
            ablak.Add(futtat, szunet, kovetkezo, alap, kezi, bal, banya, konzolKeret, naploKeret, kilep, sugo, allapot);
            Application.Top.Add(ablak);
            NezetFrissit();
        }

        static TextView SzovegNezet()
        {
            TextView t = new TextView();
            // Az olvasható szövegpanelek háttere fókuszban is fekete marad.
            ColorScheme szovegSzin = new ColorScheme();
            szovegSzin.Normal = Terminal.Gui.Attribute.Make(Color.Gray, Color.Black);
            szovegSzin.Focus = szovegSzin.Normal;
            szovegSzin.HotNormal = szovegSzin.Normal;
            szovegSzin.HotFocus = szovegSzin.Normal;
            szovegSzin.Disabled = szovegSzin.Normal;
            t.ColorScheme = szovegSzin;
            t.Width = Dim.Fill(); t.Height = Dim.Fill(); t.ReadOnly = true; t.WordWrap = false;
            return t;
        }

        void Forras() { blokkNezet = false; NezetFrissit(); }
        void Blokkok() { blokkNezet = true; NezetFrissit(); }
        void NezetFrissit()
        {
            paletta.Visible = blokkNezet;
            forrasGomb.ColorScheme = Colors.Base;
            blokkGomb.ColorScheme = Colors.Base;
            if (blokkNezet) blokkGomb.ColorScheme = aktivSzin;
            else forrasGomb.ColorScheme = aktivSzin;
            if (blokkNezet) kod.X = 22;
            else kod.X = 0;
            bal.Title = "KÓD";
            KodFrissit(false);
        }

        void KodFrissit(bool kovetes)
        {
            int regi = kod.SelectedItem;
            szerkeszto.Frissit();
            List<string> lista = new List<string>();
            for (int i = 0; i < szerkeszto.forras.Count; i++)
            {
                string jel = "  ";
                if (indult && !Motor.kesz && Motor.PC == i) jel = "> ";
                string sor = szerkeszto.forras[i];
                if (blokkNezet)
                {
                    BlokkSor adat = szerkeszto.sorok[i];
                    sor = new string(' ', adat.melyseg * 2) + "[ " + sor.TrimStart() + " ]";
                }
                lista.Add(jel + (i + 1).ToString().PadLeft(3) + " " + sor);
            }
            if (lista.Count == 0) lista.Add("(Üres program)");
            kod.SetSource(lista);
            if (kovetes && indult && !Motor.kesz) regi = Motor.PC;
            if (regi < 0) regi = 0;
            if (regi >= lista.Count) regi = lista.Count - 1;
            kod.SelectedItem = regi;
            kod.EnsureSelectedItemVisible();
        }

        void Beszuras()
        {
            Szunet();
            int kijelolt = kod.SelectedItem;
            string tipus = tipusok[tipusLista.SelectedItem];
            BlokkAblak ablak = new BlokkAblak(tipus, "", true, szerkeszto.sorok.Count == 0);
            ablak.Megnyit();
            if (ablak.elfogadva)
            {
                Blokk uj = new Blokk(tipus, ablak.sor);
                if (szerkeszto.Beszur(uj, kijelolt, ablak.hely))
                {
                    Alaphelyzet();
                    for (int i = 0; i < szerkeszto.sorok.Count; i++)
                        if (szerkeszto.sorok[i].blokk == uj && !szerkeszto.sorok[i].elseSor) kod.SelectedItem = i;
                    kod.EnsureSelectedItemVisible();
                }
                else MessageBox.ErrorQuery("Nem szúrható be", szerkeszto.hiba, "Rendben");
            }
        }

        void Modositas()
        {
            Szunet();
            if (szerkeszto.sorok.Count == 0) return;
            int i = kod.SelectedItem;
            Blokk b = szerkeszto.sorok[i].blokk;
            BlokkAblak ablak = new BlokkAblak(b.tipus, b.szoveg, false, false);
            ablak.Megnyit();
            if (ablak.elfogadva)
            {
                szerkeszto.Modosit(i, ablak.sor);
                Alaphelyzet();
            }
        }

        void Torles()
        {
            Szunet();
            if (szerkeszto.sorok.Count == 0) return;
            int i = kod.SelectedItem;
            int valasz = MessageBox.Query("Blokk törlése", "Törlöd a kijelölt blokkot a teljes tartalmával együtt?", "Törlés", "Mégsem");
            if (valasz == 0)
            {
                szerkeszto.Torol(i);
                Alaphelyzet();
            }
        }

        void Mentes()
        {
            Szunet();
            SaveDialog valaszto = new SaveDialog("Térkép és program mentése", "A kezdő térképet és a szerkesztett forráskódot mentjük.");
            valaszto.NameFieldLabel = "Fájlnév:";
            valaszto.FilePath = "szerkesztett.txt";
            Application.Run(valaszto);
            string ut = valaszto.FilePath.ToString();
            bool megsem = valaszto.Canceled;
            valaszto.Dispose();
            if (megsem || ut == "") return;
            if (string.Equals(Path.GetFullPath(ut), Path.GetFullPath(Program.outputfajl), StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.ErrorQuery("Nem menthető ide", "A naplófájl neve nem lehet a mentett program neve.", "Rendben");
                return;
            }
            if (File.Exists(ut) && MessageBox.Query("Felülírás", "A fájl már létezik. Felülírod?", "Igen", "Mégsem") != 0) return;
            try
            {
                szerkeszto.Frissit();
                using (StreamWriter f = new StreamWriter(ut, false, new UTF8Encoding(false)))
                {
                    f.WriteLine(Program.row + " " + Program.col);
                    for (int i = 0; i < Program.row; i++)
                    {
                        string sor = "";
                        for (int j = 0; j < Program.col; j++) sor += Program.barlang[i, j];
                        f.WriteLine(sor);
                    }
                    for (int i = 0; i < szerkeszto.forras.Count; i++) f.WriteLine(szerkeszto.forras[i]);
                }
                allapot.Text = "Program elmentve.";
            }
            catch (IOException hiba) { FajlHiba(hiba.Message); }
            catch (UnauthorizedAccessException hiba) { FajlHiba(hiba.Message); }
        }

        void Alaphelyzet()
        {
            IdozitoLeallit();
            Program.Alaphelyzet();
            indult = false;
            Frissit(false);
        }

        bool Elokeszit()
        {
            if (indult && !Motor.kesz) return true;
            try
            {
                szerkeszto.Frissit();
                Program.parancsok = new List<string>(szerkeszto.forras);
                Program.csendes = true; // A kiírások a Konzol panelbe kerülnek.
                Motor.Kezd();
                indult = true;
                return true;
            }
            catch (IOException hiba) { FajlHiba(hiba.Message); }
            catch (UnauthorizedAccessException hiba) { FajlHiba(hiba.Message); }
            return false;
        }

        void Futtatas()
        {
            if (automatikus || !Elokeszit()) return;
            if (!Motor.kesz)
            {
                automatikus = true;
                idozito = Application.MainLoop.AddTimeout(TimeSpan.FromMilliseconds(350), IdozitettLepes);
            }
            Frissit(true);
        }

        bool IdozitettLepes(MainLoop ciklus)
        {
            if (!automatikus) return false;
            EgyLepes();
            if (!automatikus) idozito = null;
            return automatikus;
        }

        void Kovetkezo()
        {
            IdozitoLeallit();
            if (Elokeszit()) EgyLepes();
        }

        void EgyLepes()
        {
            try
            {
                if (!Motor.kesz) Motor.Lepes();
                Frissit(true);
            }
            catch (IOException hiba) { FajlHiba(hiba.Message); }
            catch (UnauthorizedAccessException hiba) { FajlHiba(hiba.Message); }
        }

        void Szunet() { IdozitoLeallit(); Frissit(false); }
        void IdozitoLeallit()
        {
            automatikus = false;
            if (idozito != null)
            {
                Application.MainLoop.RemoveTimeout(idozito);
                idozito = null;
            }
        }

        void FajlHiba(string uzenet)
        {
            IdozitoLeallit();
            Program.Bezar();
            indult = false;
            Frissit(false);
            MessageBox.ErrorQuery("Fájlhiba", uzenet, "Rendben");
        }

        void Frissit(bool kovetes)
        {
            int x = Robot.oszlop;
            int y = Robot.sor;
            if (Robot.Irany == '>') x++;
            else if (Robot.Irany == '<') x--;
            else if (Robot.Irany == '^') y--;
            else if (Robot.Irany == 'v') y++;
            char jel = Robot.Mezo(x, y); // A kijelzés nem hív IsThere-t, nem fedez fel mezőt.
            string erzekelo = "üres kamra";
            if (jel == '@') erzekelo = "aranyrög";
            else if (jel == '#') erzekelo = "fal";
            szenzor.Text = "Előtte: " + erzekelo + " | " + Robot.Irany;
            arany.Text = "Kibányászott arany: " + Robot.arany;
            string szoveg = "";
            for (int i = 0; i < Robot.valtozok.Count; i++)
            {
                Valtozo v = Robot.valtozok[i];
                string tipus = "egész";
                if (v.logikai) tipus = "logikai";
                szoveg += v.nev + " | " + tipus + " | " + v.Szoveg() + Environment.NewLine;
            }
            if (szoveg == "") szoveg = "Még nincs változó.";
            valtozok.Text = szoveg;
            konzol.Text = string.Join(Environment.NewLine, Robot.konzol);
            naplo.Text = string.Join(Environment.NewLine, Naplo.naplo_sorok);
            if (kovetes) { konzol.MoveEnd(); naplo.MoveEnd(); }
            allapot.Text = "Indításra kész. Tab: váltás; Enter: választás.";
            if (indult)
            {
                if (Motor.kesz)
                {
                    automatikus = false;
                    allapot.Text = "Futás vége. Feldolgozott sorok: " + Naplo.feldolgozott_sorok;
                    if (Robot.hiba != "") allapot.Text = Robot.hiba;
                }
                else allapot.Text = "Következő sor: " + (Motor.PC + 1) + " | Feldolgozva: " + Naplo.feldolgozott_sorok;
            }
            futtat.Enabled = !automatikus;
            kovetkezo.Enabled = !automatikus;
            szunet.Enabled = automatikus;
            KodFrissit(kovetes);
            terkep.SetNeedsDisplay();
        }

        void Sugo()
        {
            Szunet();
            MessageBox.Query("Használat", "Forráskód: a szerkesztett program szövege.\nBlokkok: bal oldalt típus, jobb oldalt célblokk.\n"
                + "Beszúr: elé, mögé, törzsbe, else ágba vagy a program végére.\n"
                + "Módosít: paraméterek szerkesztése. Töröl: a teljes blokk törlése.\n"
                + "Legfeljebb három egymásba ágyazott vezérlőblokk lehet.\n"
                + "Alaphelyzet: a robotot állítja vissza, a szerkesztést megtartja.\n"
                + "Mentés: kezdő térkép és szerkesztett kód egy új bemeneti fájlba.\n"
                + "Ajánlott ablakméret: 120 × 44, legalább 100 × 40.\n"
                + "Kézi vezérlés: lépés, balra fordulás és bányászás napló nélkül.\n"
                + "A változók int-ek; túl nagy számításnál a futás leáll.", "Rendben");
        }

        void KeziVezerles()
        {
            Szunet();
            Dialog kez = new Dialog("Kézi robotvezérlés", 66, 12);
            kez.Add(new Label("Az első művelet megszakítja a programot. Nincs naplózás.") { X = 1, Y = 1 });
            Button lep = new Button("Lépés"); lep.X = 1; lep.Y = 3; lep.Clicked += KeziLepes;
            Button fordul = new Button("Balra fordul"); fordul.X = 15; fordul.Y = 3; fordul.Clicked += KeziFordul;
            Button banyasz = new Button("Bányászás"); banyasz.X = 36; banyasz.Y = 3; banyasz.Clicked += KeziBanyasz;
            keziAllapot = new Label("A bányában a robot aktuális helyzetéből folytatod.");
            keziAllapot.X = 1; keziAllapot.Y = 5; keziAllapot.Width = Dim.Fill(2);
            kez.Add(lep, fordul, banyasz, keziAllapot);
            Button vissza = new Button("Vissza"); vissza.Clicked += KeziBezar;
            kez.AddButton(vissza);
            Application.Run(kez);
            kez.Dispose();
            keziAllapot = null;
        }

        Label keziAllapot;
        void KeziBezar() { Application.RequestStop(); }
        void KeziLepes() { KeziMuvelet(0); }
        void KeziFordul() { KeziMuvelet(1); }
        void KeziBanyasz() { KeziMuvelet(2); }

        void KeziMuvelet(int muvelet)
        {
            IdozitoLeallit();
            // A pillanatnyi térképet megtartjuk, csak a program futását szakítjuk meg.
            Motor.kesz = true;
            Program.Bezar();
            indult = false;
            Robot.hiba = "";
            string uzenet = "Kézi vezérlés: nincs naplózás.";
            try
            {
                if (muvelet == 0) Robot.Lepes(1);
                else if (muvelet == 1) Robot.Fordulasok(1);
                else if (muvelet == 2) Robot.Mine();
            }
            catch (InvalidOperationException hiba)
            {
                // Kézzel falnak lépve megállunk, nem fejeződik be hibával az alkalmazás.
                if (hiba.Message == "E_BEDROCK_HIT") uzenet = "Fal: a robot megállt.";
                else if (hiba.Message == "E_NO_GOLD") uzenet = "Ezen a mezőn nincs arany.";
                else uzenet = hiba.Message;
            }
            Frissit(false);
            allapot.Text = uzenet;
            if (keziAllapot != null) keziAllapot.Text = uzenet;
        }

        void Kilepes()
        {
            Szunet();
            int valasz = MessageBox.Query("Kilépés", "Kilépsz? A még nem mentett szerkesztés elvész.", "Kilépés", "Mégsem");
            if (valasz == 0) Application.RequestStop();
        }
    }

    // A keret fehér marad, csak a címet rajzoljuk újra lilával.
    internal class LilaKeret : FrameView
    {
        public LilaKeret(string cim) : base(cim) { }

        public override void Redraw(Rect terulet)
        {
            base.Redraw(terulet);
            Driver.SetAttribute(Terminal.Gui.Attribute.Make(Color.BrightMagenta, Color.Black));
            int x = 0;
            int y = 0;
            View szulo = this;
            while (szulo != null)
            {
                x += szulo.Frame.X;
                y += szulo.Frame.Y;
                szulo = szulo.SuperView;
            }
            Driver.DrawWindowTitle(new Rect(x - 1, y - 1, Frame.Width + 2, Frame.Height + 2), Title,
                1, 1, 1, 1, TextAlignment.Left);
        }
    }

    internal class TerkepNezet : View
    {
        public override void Redraw(Rect terulet)
        {
            for (int i = 0; i < Program.row; i++)
            {
                for (int j = 0; j < Program.col; j++)
                {
                    char jel = '?';
                    if (Robot.felfedezett[i, j]) jel = Robot.barlang[i, j];
                    Color szin = Color.Gray;
                    if (jel == '@') szin = Color.BrightYellow;
                    if (jel == '?') szin = Color.DarkGray;
                    if (i == Robot.sor && j == Robot.oszlop) { jel = Robot.Irany; szin = Color.BrightMagenta; }
                    Move(j * 2, i);
                    Driver.SetAttribute(Terminal.Gui.Attribute.Make(szin, Color.Black));
                    Driver.AddStr(jel + " ");
                }
            }
        }
    }
}
