using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DuszaVerseny26
{
    internal class Naplo
    {
        public static List<string> naplo_sorok = new List<string>();
        public static int feldolgozott_sorok = 0;
        static StreamWriter fajl;
        static string aktualis_sor = "";
        static bool befejezve;

        public static void Alaphelyzet()
        {
            Bezar();
            naplo_sorok.Clear();
            feldolgozott_sorok = 0;
            aktualis_sor = "";
            befejezve = false;
        }

        public static void Kezd()
        {
            Alaphelyzet();
            fajl = new StreamWriter(Program.outputfajl, false, new UTF8Encoding(false));
            fajl.AutoFlush = true;
        }

        public static void Sor_kiiras(int sorszam)
        {
            aktualis_sor = sorszam.ToString();
        }

        public static void Api_kiiras(int sorszam, string apinev)
        {
            aktualis_sor = sorszam + " " + apinev;
        }

        public static void Api_kiiras(int sorszam, string apinev, string parameter)
        {
            aktualis_sor = sorszam + " " + apinev + " " + parameter;
        }

        public static void Api_kiiras(int sorszam, string apinev, string parameter, string visszateres)
        {
            aktualis_sor = sorszam + " " + apinev + " " + parameter + " " + visszateres;
        }

        public static void Api_nem_inicializalt(int sorszam, string apinev)
        {
            Api_kiiras(sorszam, apinev);
            Hiba("E_UNINITIALIZED");
        }

        public static void SorVege()
        {
            if (befejezve || aktualis_sor == "") return;
            EllenorizEsHozzaad(aktualis_sor);
            feldolgozott_sorok++;
            aktualis_sor = "";
        }

        public static void Hiba(string hibakod)
        {
            if (befejezve) return;
            aktualis_sor += " " + hibakod;
            SorVege();
            MentesEsLeallitas(false);
        }
        public static bool Folytathato()
        {
            if (befejezve) return false;
            if (feldolgozott_sorok < 1000) return true;
            MentesEsLeallitas(true);
            return false;
        }

        private static void EllenorizEsHozzaad(string sor)
        {
            naplo_sorok.Add(sor);
            fajl.WriteLine(sor);
        }

        public static void MentesEsLeallitas(bool limitTullepes)
        {
            if (befejezve) return;
            if (limitTullepes)
                EllenorizEsHozzaad("INSTRUCTION_COUNT_LIMIT_EXCEEDED");
            else
                EllenorizEsHozzaad("EOR");
            befejezve = true;
            Motor.kesz = true;
            Bezar();
        }

        public static void Bezar()
        {
            if (fajl != null)
            {
                fajl.Close();
                fajl = null;
            }
        }
    }
}
