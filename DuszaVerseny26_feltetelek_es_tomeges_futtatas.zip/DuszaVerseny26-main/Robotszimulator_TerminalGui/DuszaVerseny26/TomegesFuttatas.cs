using System;
using System.IO;

namespace DuszaVerseny26
{
    // Minden bemenet külön futást és külön naplófájlt kap.
    internal class TomegesFuttatas
    {
        public static void Indit(string bemenetMappa, string naploMappa)
        {
            try
            {
                // Külön mappát kérünk, hogy a naplók ne váljanak új bemenetté.
                string bemenetUt = Path.GetFullPath(bemenetMappa).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string naploUt = Path.GetFullPath(naploMappa).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                if (string.Equals(bemenetUt, naploUt, StringComparison.OrdinalIgnoreCase))
                    throw new IOException("A bemenetek és a naplók külön mappában legyenek.");
                Directory.CreateDirectory(naploMappa);
                string[] fajlok = Directory.GetFiles(bemenetMappa, "*.txt");
                Array.Sort(fajlok);
                int sikeres = 0;
                int hibas = 0;
                for (int i = 0; i < fajlok.Length; i++)
                {
                    string nev = Path.GetFileNameWithoutExtension(fajlok[i]);
                    string naplo = Path.Combine(naploMappa, nev + "_output.txt");
                    try
                    {
                        // Az eredeti bemenetet nem írjuk felül naplóval.
                        if (string.Equals(Path.GetFullPath(fajlok[i]), Path.GetFullPath(naplo), StringComparison.OrdinalIgnoreCase))
                            throw new IOException("A bemenet és a napló ugyanaz a fájl.");
                        Program.Beolvadas(new string[] { "-q", fajlok[i], naplo });
                        Motor.ProgramFuttatas();
                        if (Robot.hiba == "")
                        {
                            sikeres++;
                            Console.WriteLine((i + 1) + "/" + fajlok.Length + " Kész: " + nev);
                        }
                        else
                        {
                            hibas++;
                            Console.WriteLine((i + 1) + "/" + fajlok.Length + " " + nev + ": " + Robot.hiba);
                        }
                    }
                    catch (IOException hiba)
                    {
                        hibas++;
                        Console.WriteLine(nev + ": " + hiba.Message);
                    }
                    catch (UnauthorizedAccessException hiba)
                    {
                        hibas++;
                        Console.WriteLine(nev + ": " + hiba.Message);
                    }
                    finally { Program.Bezar(); }
                }
                Console.WriteLine("Összesen: " + fajlok.Length + ", sikeres: " + sikeres + ", hibával lezárt: " + hibas);
                if (fajlok.Length == 0) Console.WriteLine("Nincs .txt fájl a bemeneti mappában.");
                if (hibas > 0) Environment.ExitCode = 1;
            }
            catch (IOException hiba)
            {
                Console.Error.WriteLine(hiba.Message);
                Environment.ExitCode = 1;
            }
            catch (UnauthorizedAccessException hiba)
            {
                Console.Error.WriteLine(hiba.Message);
                Environment.ExitCode = 1;
            }
        }
    }
}
