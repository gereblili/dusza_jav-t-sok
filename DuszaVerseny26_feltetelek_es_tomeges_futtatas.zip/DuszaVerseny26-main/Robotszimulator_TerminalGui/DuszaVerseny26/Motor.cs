using System;
using System.Collections.Generic;

namespace DuszaVerseny26
{
    internal class Motor
    {
        public static int PC;
        public static bool kesz;
        static int[] behuzas;
        static int[] vegek;
        static bool[] elseAg;
        static List<int> while_szamok = new List<int>();

        public static void Alaphelyzet()
        {
            PC = 0;
            kesz = false;
            while_szamok.Clear();
        }

        public static void ProgramFuttatas()
        {
            Kezd();
            while (!kesz) Lepes();
        }

        public static void Kezd()
        {
            Program.Alaphelyzet();
            int n = Program.parancsok.Count;
            behuzas = new int[n];
            vegek = new int[n];
            elseAg = new bool[n];
            while_szamok.Clear();
            for (int i = 0; i < n; i++)
            {
                int j = 0;
                while (j < Program.parancsok[i].Length && Program.parancsok[i][j] == ' ')
                    j++;
                behuzas[i] = j;
            }
            for (int i = 0; i < n; i++)
            {
                int j = i + 1;
                while (j < n && behuzas[j] > behuzas[i])
                    j++;
                vegek[i] = j;
            }
            Naplo.Kezd();
            Rendez();
        }
        public static void Bezar()
        {
            Naplo.Bezar();
        }
        static void Befejez()
        {
            Naplo.MentesEsLeallitas(false);
        }
        static void Rendez()
        {
            bool rendben = false;
            while (rendben == false)
            {
                if (while_szamok.Count > 0)
                {
                    int utolso = while_szamok.Count - 1;
                    int ciklusSor = while_szamok[utolso];
                    if (PC >= vegek[ciklusSor])
                    {
                        PC = ciklusSor;
                        while_szamok.RemoveAt(utolso);
                    }
                }
                if (PC < Program.parancsok.Count && Program.parancsok[PC].TrimStart() == "else"
                    && elseAg[PC] == false)
                {
                    PC = vegek[PC];
                }
                else
                {
                    rendben = true;
                }
            }
            if (PC >= Program.parancsok.Count)
            {
                Befejez();
            }
        }
        public static void Lepes()
        {
            if (kesz == true) return;
            if (!Naplo.Folytathato())
            {
                Robot.hiba = "INSTRUCTION_COUNT_LIMIT_EXCEEDED";
                Robot.Kiir(Robot.hiba);
                kesz = true;
                Bezar();
                return;
            }
            int i = PC;
            Naplo.Sor_kiiras(i + 1);
            Parancs parancs;
            try
            {
                parancs = new Parancs(Program.parancsok[i]);
            }
            catch (InvalidOperationException hiba)
            {
                Robot.hiba = hiba.Message;
                Robot.Kiir((i + 1) + ". sor: " + Robot.hiba);
                Naplo.Hiba(Robot.hiba);
                return;
            }
            Naplo.SorVege();
            PC = i + 1;
            if (parancs.sor.StartsWith("if "))
            {
                int vege = vegek[i];
                bool vanElse = false;
                if (vege < Program.parancsok.Count && behuzas[vege] == behuzas[i]
                    && Program.parancsok[vege].TrimStart() == "else")
                {
                    vanElse = true;
                    elseAg[vege] = false;
                }
                if (parancs.feltetel == false)
                {
                    PC = vege;
                    if (vanElse == true) elseAg[vege] = true;
                }
            }
            else if (parancs.sor.StartsWith("while "))
            {
                if (parancs.feltetel == true)
                    while_szamok.Add(i);
                else
                    PC = vegek[i];
            }
            else if (parancs.sor == "else")
            {
                elseAg[i] = false;
            }
            Rendez();
        }
    }
}
