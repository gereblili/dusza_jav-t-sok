@echo off
cd /d "%~dp0"
dotnet run --project Robotszimulator_net8.csproj -- pelda.txt output.txt
if errorlevel 1 pause
