@echo off
cd /d "%~dp0"
"Futtathato_Windows\DuszaVerseny26.exe" --batch "inputok" "naplok"
pause
