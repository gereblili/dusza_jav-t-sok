@echo off
cd /d "%~dp0"
DuszaVerseny26.exe pelda.txt output.txt
if errorlevel 1 pause
