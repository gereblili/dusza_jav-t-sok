using System;
using System.Collections.Generic;


namespace DuszaVerseny26
{
    internal class Robot
    {
        public static char Irany; // ^-fel, >-jobbra, v-le, <-balra
        public static int sor; // Függőleges koordináta.
        public static int oszlop; // Vízszintes koordináta. 
        public static char alatta = '.'; // mi van a robot alatt ahol épp áll eredetileg mindig ures kamra '.' van alatta.
        public static int arany; //összegyűjtött aranyszám
        public static char[,] barlang; //barlang a robot nélkül

        public static string hiba = "";
        public static List<string> konzol = new List<string>();
        public static bool[,] felfedezett;

        public static List<Valtozo> valtozok = new List<Valtozo>();

        public static void Betolt(char[,] terkep) //Bánya a robot nélkül
        {
            // Másolat kell: a bányászás ne változtassa meg a kezdő térképet.
            barlang = new char[Program.row, Program.col];
            felfedezett = new bool[Program.row, Program.col];
            hiba = "";
            konzol.Clear();
            for (int i = 0; i < Program.row; i++)
                for (int j = 0; j < Program.col; j++)
                    barlang[i, j] = terkep[i, j];
            arany = 0;
            for (int i = 0; i < Program.row; i++)
            {
                for (int j = 0; j < Program.col; j++)
                {
                    char jel = barlang[i, j];
                    if (jel == '^' || jel == '>' || jel == 'v' || jel == '<')
                    {
                        sor = i;
                        oszlop = j;
                        Irany = jel;
                        barlang[i, j] = '.';
                        felfedezett[i, j] = true;
                    }
                }
            }
            alatta = '.';
        }

        public static char Mezo(int oszlop, int sor) // Mi van a mezon?
        {
            if (sor < 0 || sor >= Program.row) return '#';
            if (oszlop < 0 || oszlop >= Program.col) return '#';
            return barlang[sor, oszlop];
        }

        public static void Lepes(int lepes)
        {
            if (lepes < 0) throw new InvalidOperationException("E_BAD_ARG");
            int ujX = sor;
            int ujY = oszlop;
            for (int lepteto = 0; lepteto < lepes; lepteto++)
            {
                if (Irany == '>') ujY++;
                else if (Irany == '<') ujY--;
                else if (Irany == '^') ujX--;
                else if (Irany == 'v') ujX++;
                if (Mezo(ujY, ujX) == '#')
                    throw new InvalidOperationException("E_BEDROCK_HIT");
                sor = ujX;
                oszlop = ujY;
                alatta = barlang[sor, oszlop];
                felfedezett[sor, oszlop] = true;
            }
        }

        public static void Fordul() //Mindig 90 fokkal fordul balra
        {
            if (Irany == '>')
                Irany = '^';
            else if (Irany == '^')
                Irany = '<';
            else if (Irany == '<')
                Irany = 'v';
            else if (Irany == 'v')
                Irany = '>';
        }

        //n darab negyedfordulatot megy balra
        public static void Fordulasok(int mennyiseg) // Turn
        {
            if (mennyiseg < 0) throw new InvalidOperationException("E_BAD_ARG");
            mennyiseg = mennyiseg % 4; //Azért osztunk néggyel, mert négy negyedfordulat után a robot visszakerül az eredeti irányába.
            for (int i = 0; i < mennyiseg; i++)
                Fordul();
        }
        public static void Mine()
        {
            if (barlang[sor, oszlop] != '@') throw new InvalidOperationException("E_NO_GOLD");
            barlang[sor, oszlop] = '.';
            alatta = '.';
            arany++;
        }

        public static bool IsThere(int mit)
        {
            if (mit < 0 || mit > 2) throw new InvalidOperationException("E_BAD_ARG");

            int ujX = sor;
            if (Irany == '^')
                ujX--;
            else if (Irany == 'v')
                ujX++;

            int ujY = oszlop;
            if (Irany == '>')
                ujY++;
            else if (Irany == '<')
                ujY--;

            if (ujX >= 0 && ujX < Program.row && ujY >= 0 && ujY < Program.col)
                felfedezett[ujX, ujY] = true;
            char jel = Mezo(ujY, ujX);
            if (mit == 0) return jel == '.';
            if (mit == 1) return jel == '#';
            return jel == '@';
        }
        static bool Betu(char betu) => (betu >= 'a' && betu <= 'z') || (betu >= 'A' && betu <= 'Z');
        public static bool JoNev(string nev) //VÁLTOZÓNÉV ELLENŐRZÉSE
        {
            if (nev.Length == 0 || !Betu(nev[0])) return false;  //Nem üres és betu az elso betu, ez nem tudom h kell e
            for (int i = 1; i < nev.Length; i++)//betu és szám van csak benne
            {
                if (!Betu(nev[i]) && (nev[i] < '0' || nev[i] > '9')) return false;
            }
            string[] tiltott = { "and", "by", "else", "false", "forward", "here", "if", "isthere", "mine", "not", "or", "print", "set", "step", "to", "true", "turn", "while" }; //Lehet hogy kihagytam valamit
            for (int i = 0; i < tiltott.Length; i++)
            {
                if (nev.ToLowerInvariant() == tiltott[i]) return false;
            }
            return true;
        }

        //OLVAS: Az Olvas() függvény a kapott szöveget megvizsgálja, és megpróbál belőle egy Valtozo objektumot létrehozni.
        //Először ellenőrzi, hogy a szöveg true vagy false érték-e, majd azt, hogy szám-e (0 és 100 között);
        //ha igen, eltárolja az értékét. Ha egyik sem, akkor változónévként kezeli, megkeresi a változólistában,
        //és átmásolja annak adatait az eredmeny objektumba. Ha hibás számot vagy nem létező változót talál, kivételt (Exception) dob, végül pedig visszaadja az elkészült Valtozo objektumot.
        public static Valtozo Olvas(string szoveg)
        {
            Valtozo eredmeny = new Valtozo();
            if(szoveg == "true")
            {
                eredmeny.logikai = true;
                eredmeny.igaz = true;
            }
            else if (szoveg == "false")
            {
                eredmeny.logikai = true;
                eredmeny.igaz = false;
            }
            else if (szoveg.Length > 0 && szoveg[0] >= '0' && szoveg[0] <= '9') //Ha szám akkor megadjuk azt neki értéknek
            {
                int szam;
                bool sikerult = int.TryParse(szoveg, out szam);
                if (sikerult == false || szam < 0 || szam > 100)
                {
                    throw new InvalidOperationException( "Hibás szám a forráskódban: " + szoveg);
                }
                else
                {
                    eredmeny.ertek = szam;
                }
            }
            else
            {
                int hely = Keres(szoveg);
                if (hely == -1)
                {
                    throw new InvalidOperationException("E_UNINITIALIZED");
                }
                else
                {
                    eredmeny.logikai = valtozok[hely].logikai;
                    eredmeny.ertek = valtozok[hely].ertek;
                    eredmeny.igaz = valtozok[hely].igaz;
                }
            }
            return eredmeny;
        }
        public static int Keres(string nev)
        {
            int hely = -1;
            int i = 0;
            while (i < valtozok.Count && hely == -1)
            {
                if (valtozok[i].nev == nev)
                {
                    hely = i;
                }
                i++;
            }
            return hely;
        }

        public static Valtozo Kifejezes(string szoveg)
        {
            string[] p = szoveg.Split(' ');
            Valtozo eredmeny = new Valtozo();
            if(p.Length == 1)
            {
                eredmeny = Olvas(p[0]);
            }
            else if (p[0] == "isThere")
            {
                Naplo.Api_kiiras(Motor.PC + 1, "isThere");
                Valtozo parameter = Olvas(p[1]);
                Naplo.Api_kiiras(Motor.PC + 1, "isThere", parameter.Szoveg());
                if(parameter.logikai == true)
                {
                    throw new InvalidOperationException("E_BAD_ARG");
                }
                else
                {
                    eredmeny.logikai = true;
                    eredmeny.igaz = IsThere(parameter.ertek);
                    Naplo.Api_kiiras(Motor.PC + 1, "isThere", parameter.Szoveg(), eredmeny.Szoveg());
                }
            }
            else if (p[0] == "not")
            {
                Valtozo parameter = Olvas(p[1]);
                if(parameter.logikai == false)
                {
                    throw new InvalidOperationException("E_BAD_OPERAND");
                }
                else
                {
                    eredmeny.logikai = true;
                    eredmeny.igaz = !parameter.igaz;
                }
            }
            else if(p.Length ==3)
            {
                string muvelet = p[1];
                Valtozo bal = Olvas(p[0]);
                bool egyenloseg = muvelet == "=" || muvelet =="<>";
                bool logikaiMuvelet = muvelet == "and" || muvelet == "or";

                if(egyenloseg == false)
                {
                    if (logikaiMuvelet == true && bal.logikai == false)
                    {
                        throw new InvalidOperationException("E_BAD_OPERAND");
                    }
                    else if (logikaiMuvelet == false && bal.logikai == true)
                    {
                        throw new InvalidOperationException("E_BAD_OPERAND");
                    }
                }
                Valtozo jobb = Olvas(p[2]);
                if(bal.logikai != jobb.logikai)
                {
                    throw new InvalidOperationException("E_BAD_OPERAND");
                }
                else
                {
                    eredmeny = Muvelet(bal, muvelet, jobb);
                }
            }
            else
            {
                throw new InvalidOperationException("Érvénytelen kifejezés: " + szoveg);
            }
            return eredmeny;
        }
        static Valtozo Muvelet(Valtozo bal, string muvelet, Valtozo jobb)
        {
            Valtozo eredmeny = new Valtozo();
            long szam = 0; // A köztes eredményből ellenőrizzük az int túlcsordulását.
            if (muvelet == "+" || muvelet == "-" || muvelet == "*")
            {
                if (muvelet == "+")
                    szam = (long)bal.ertek + jobb.ertek;
                else if (muvelet == "-")
                    szam = (long)bal.ertek - jobb.ertek;
                else if (muvelet == "*")
                    szam = (long)bal.ertek * jobb.ertek;
                if (szam < int.MinValue || szam > int.MaxValue)
                    throw new InvalidOperationException("A számítás eredménye nem fér el az int típusban.");
                eredmeny.ertek = (int)szam;
            }
            else
            {
                eredmeny.logikai = true;
                if (muvelet == "=")
                    {
                    if (bal.logikai) eredmeny.igaz = bal.igaz == jobb.igaz;
                    else eredmeny.igaz = bal.ertek == jobb.ertek;
                }
                else if (muvelet == "<>")
                    {
                    if (bal.logikai) eredmeny.igaz = bal.igaz != jobb.igaz;
                    else eredmeny.igaz = bal.ertek != jobb.ertek;
                }
                else if (muvelet == "<")
                    eredmeny.igaz = bal.ertek < jobb.ertek;
                else if (muvelet == "<=")
                    eredmeny.igaz = bal.ertek <= jobb.ertek;
                else if (muvelet == ">")
                    eredmeny.igaz = bal.ertek > jobb.ertek;
                else if (muvelet == ">=")
                    eredmeny.igaz = bal.ertek >= jobb.ertek;

                else if (muvelet == "and")
                    eredmeny.igaz = bal.igaz && jobb.igaz;
                else if (muvelet == "or")
                    eredmeny.igaz = bal.igaz || jobb.igaz;
                else
                    eredmeny.ertek = (int)szam;
            }
            return eredmeny;
        }

        public static void Print(string szoveg)
        {
            Naplo.Api_kiiras(Motor.PC + 1, "print");
            Valtozo adat = Olvas(szoveg);
            Naplo.Api_kiiras(Motor.PC + 1, "print", adat.Szoveg());
            Kiir(adat.Szoveg());
        }

        public static void Kiir(string szoveg) { konzol.Add(szoveg); }

        public static void Set(string nev, string ertek)
        {
            Valtozo uj = new Valtozo();
            if (JoNev(nev) == false)
            {
                throw new InvalidOperationException("Érvénytelen változónév: " + nev);
            }
            else
            {
                uj = Kifejezes(ertek); // Előbb kiszámoljuk, csak siker után tároljuk.
                int hely = Keres(nev);
                if (hely == -1)
                {
                    uj.nev = nev;
                    valtozok.Add(uj);
                }
                else if (valtozok[hely].logikai != uj.logikai)
                {
                    throw new InvalidOperationException("E_TYPE_MISMATCH");
                }
                else
                {
                    valtozok[hely].ertek = uj.ertek;
                    valtozok[hely].igaz = uj.igaz;
                }
            }
        }
    }
}
