using System;
using System.Collections.Generic;

namespace DuszaVerseny26
{
    // A feladat helyes bemenetet ígér. Ez a kiegészítés a kézzel írt hibás
    // teszteknél segít: nem engedi, hogy egy utasítás végét csendben elhagyjuk.
    internal class BemenetEllenorzes
    {
        public static void Forras(List<string> sorok)
        {
            List<int> szintek = new List<int>();
            List<bool> lehetElse = new List<bool>();
            szintek.Add(0);
            lehetElse.Add(false);
            string elozo = "";
            int elozoBehuzas = 0;
            for (int i = 0; i < sorok.Count; i++)
            {
                string sor = sorok[i];
                int behuzas = 0;
                while (behuzas < sor.Length && sor[behuzas] == ' ') behuzas++;
                if (behuzas == sor.Length) Hiba(i, "Üres programsor nem megengedett.");
                if (sor.IndexOf('\t') >= 0) Hiba(i, "Behúzáshoz szóközt használj, ne tabot.");
                string[] p = sor.Substring(behuzas).Split(' ');
                for (int j = 0; j < p.Length; j++)
                    if (p[j] == "") Hiba(i, "A szavak között pontosan egy szóköz legyen.");
                // A kezdő szintet az első sor adja; a további szintek ehhez igazodnak.
                if (i == 0)
                {
                    szintek[0] = behuzas;
                    elozoBehuzas = behuzas;
                }
                if (behuzas > elozoBehuzas)
                {
                    if (elozo != "if" && elozo != "while" && elozo != "else")
                        Hiba(i, "Csak vezérlőutasítás után kezdődhet belső blokk.");
                    szintek.Add(behuzas);
                    lehetElse.Add(false);
                }
                else
                {
                    while (szintek.Count > 1 && szintek[szintek.Count - 1] > behuzas)
                    {
                        szintek.RemoveAt(szintek.Count - 1);
                        lehetElse.RemoveAt(lehetElse.Count - 1);
                    }
                    if (szintek[szintek.Count - 1] != behuzas)
                        Hiba(i, "A behúzás nem illeszkedik a külső blokkhoz.");
                }
                int szint = szintek.Count - 1;
                if ((p[0] == "if" || p[0] == "while") && szint >= 3)
                    Hiba(i, "Legfeljebb három vezérlőszint megengedett.");
                if (p[0] == "else")
                {
                    if (p.Length != 1 || !lehetElse[szint]) Hiba(i, "Az else előtt azonos szintű if szükséges.");
                    lehetElse[szint] = false;
                }
                else
                {
                    Utasitas(p, i);
                    lehetElse[szint] = p[0] == "if";
                }
                elozo = p[0];
                elozoBehuzas = behuzas;
            }
        }

        static void Utasitas(string[] p, int i)
        {
            if (p[0] == "step" || p[0] == "turn")
            {
                string szo = "forward";
                if (p[0] == "turn") szo = "by";
                if (p.Length != 3 || p[1] != szo) Hiba(i, "Hibás mozgásutasítás.");
                Ertek(p[2], i);
            }
            else if (p[0] == "mine")
            {
                if (p.Length != 2 || p[1] != "here") Hiba(i, "A helyes alak: mine here.");
            }
            else if (p[0] == "print" || p[0] == "if" || p[0] == "while")
            {
                if (p.Length != 2)
                    Hiba(i, "Itt egyetlen érték vagy változónév kell. Az összehasonlítást előbb set utasítással számold ki.");
                Ertek(p[1], i);
            }
            else if (p[0] == "set")
            {
                if (p.Length < 4 || p.Length > 6) Hiba(i, "Hibás értékadás.");
                if (!Robot.JoNev(p[1]) || p[2] != "to") Hiba(i, "Hibás változónév vagy hiányzó to.");
                if (p.Length == 4) Ertek(p[3], i);
                else if (p.Length == 5)
                {
                    if (p[3] != "not" && p[3] != "isThere") Hiba(i, "Ismeretlen egyoperandusú művelet.");
                    Ertek(p[4], i);
                }
                else
                {
                    Ertek(p[3], i);
                    string m = p[4];
                    if (m != "+" && m != "-" && m != "*" && m != "=" && m != "<>"
                        && m != "<" && m != "<=" && m != ">" && m != ">=" && m != "and" && m != "or")
                        Hiba(i, "Ismeretlen művelet: " + m);
                    Ertek(p[5], i);
                }
            }
            else Hiba(i, "Ismeretlen utasítás: " + p[0]);
        }

        static void Ertek(string s, int i)
        {
            // Nincs előzetes típusellenőrzés: ismeretlen változó is helyes név lehet.
            if (!Blokk.EgyszeruErtek(s)) Hiba(i, "0–100 közötti számliterál, true/false vagy érvényes változónév szükséges: " + s);
        }

        static void Hiba(int i, string uzenet)
        {
            throw new FormatException("A program " + (i + 1) + ". sora: " + uzenet);
        }
    }
}
