using System;
using System.Collections.Generic;
using System.IO;


namespace DuszaVerseny26
{
    internal class Valtozo
    {
        public string nev = "";
        public bool logikai = false; // Igaz esetén az igaz mezőt, különben az ertek mezőt használjuk.
        public int ertek = 0;
        public bool igaz = false;

        public string Szoveg()
        {
            if (logikai == false)
                return ertek.ToString();
            else if (igaz == true)
                return "true";
            else
                return "false";
        }
    }

    public class Parancs
    {
        public string sor;
        public bool van_e_ertek;
        public int ertek;
        public bool feltetel;
        public Parancs(string sor)
        {
            this.sor = sor.TrimStart();
            string[] p = this.sor.Split(' ');
            if (this.sor.StartsWith("step forward"))
            {
                Naplo.Api_kiiras(Motor.PC + 1, "step forward");
                Valtozo adat = Robot.Olvas(p[2]);
                Naplo.Api_kiiras(Motor.PC + 1, "step forward", adat.Szoveg());
                if (adat.logikai == true)
                    throw new InvalidOperationException("E_BAD_ARG");
                else
                {
                    van_e_ertek = true;
                    ertek = adat.ertek;
                    Robot.Lepes(ertek);
                }
            }
            else if (this.sor.StartsWith("turn by "))
            {
                Naplo.Api_kiiras(Motor.PC + 1, "turn by");
                Valtozo adat = Robot.Olvas(p[2]);
                Naplo.Api_kiiras(Motor.PC + 1, "turn by", adat.Szoveg());
                if (adat.logikai == true)
                    throw new InvalidOperationException("E_BAD_ARG");
                else
                {
                    van_e_ertek = true;
                    ertek = adat.ertek;
                    Robot.Fordulasok(ertek);
                }
            }
            else if (this.sor == "mine here")
            {
                Naplo.Api_kiiras(Motor.PC + 1, "mine here");
                Robot.Mine();
            }
            else if (this.sor.StartsWith("set "))
            {
                string kifejezes = p[3];
                for (int i = 4; i < p.Length; i++)
                {
                    kifejezes += " " + p[i];
                }
                Robot.Set(p[1], kifejezes);
            }
            else if (p[0] == "if" || p[0] == "while")
            {
                Valtozo adat = Robot.Olvas(p[1]);
                if(adat.logikai == false)
                    throw new InvalidOperationException("E_NON_BOOL_CONDITION");
                else
                    feltetel = adat.igaz;
            }
            else if (p[0] == "print")
                Robot.Print(p[1]);
            else if (this.sor != "else")
                throw new InvalidOperationException("Ismeretlen utasítás: " + this.sor);
        }
    }
}
