using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DuszaVerseny26
{
    internal class Program
    {
        public static string inputfajl;
        public static string outputfajl;
        public static bool csendes;
        public static List<string> parancsok = new List<string>();
        public static int row;
        public static int col;
        public static char[,] barlang;

        public static void Beolvadas(string[] strings)
        {
            if (strings.Length == 2)
            {
                csendes = false;
                inputfajl = strings[0];
                outputfajl = strings[1];
            }
            else
            {
                csendes = true;
                inputfajl = strings[1];
                outputfajl = strings[2];
            }
            parancsok.Clear();
            using (StreamReader f = new StreamReader(inputfajl, Encoding.UTF8))
            {
                string fejlec = f.ReadLine();
                if (fejlec == null) throw new FormatException("Hiányzik a térkép mérete.");
                string[] line = fejlec.Split(' ');
                if (line.Length != 2 || !int.TryParse(line[0], out row) || !int.TryParse(line[1], out col)
                    || row <= 0 || col <= 0)
                    throw new FormatException("A térkép mérete két pozitív egész szám legyen.");
                int robotok = 0;
                barlang = new char[row, col];
                for (int i = 0; i < row; i++)
                {
                    string charsor = f.ReadLine();
                    if (charsor == null || charsor.Length != col)
                        throw new FormatException("A térkép " + (i + 1) + ". sorának hossza nem " + col + ".");
                    for (int j = 0; j < col; j++)
                    {
                        char jel = charsor[j];
                        if (jel == '>' || jel == '<' || jel == '^' || jel == 'v') robotok++;
                        else if (jel != '.' && jel != '#' && jel != '@')
                            throw new FormatException("Ismeretlen térképjel: " + jel + ". Az arany jele @.");
                        barlang[i, j] = jel;
                    }
                }
                if (robotok != 1) throw new FormatException("A térképen pontosan egy robot legyen (>, <, ^ vagy v).");
                parancsok = new List<string>();
                while (!f.EndOfStream)
                {
                    parancsok.Add(f.ReadLine());
                }
            }
            BemenetEllenorzes.Forras(parancsok);
            Alaphelyzet();
        }
        public static void Alaphelyzet()
        {
            Bezar();
            Robot.arany = 0;
            Robot.valtozok.Clear();
            Naplo.Alaphelyzet();
            Motor.Alaphelyzet();
            Robot.Betolt(barlang);
        }
        public static void Bezar()
        {
            Naplo.Bezar();
        }
        static void Main(string[] args)
        {
            bool jo = args.Length == 2 || (args.Length == 3 && args[0] == "-q");
            if (jo == false)
            {
                Console.Error.WriteLine("Használat: DuszaVerseny26.exe [-q] input.txt output.txt");
                Environment.ExitCode = 2;
                return;
            }
            try //Ezek elméletileg nem árt ha itt vannak
            {
                Beolvadas(args);
                if (string.Equals(Path.GetFullPath(inputfajl), Path.GetFullPath(outputfajl), StringComparison.OrdinalIgnoreCase))
                {
                    Console.Error.WriteLine("A bemenet és a napló ne ugyanaz a fájl legyen!");
                    Environment.ExitCode = 2;
                    return;
                }
                if (csendes)
                {
                    Motor.ProgramFuttatas();
                }
                else
                {
                    Felulet felulet = new Felulet();
                    felulet.Indit();
                }
            }
            catch (FormatException hiba)
            {
                Console.Error.WriteLine("Bemeneti hiba: " + hiba.Message);
                Environment.ExitCode = 2;
            }
            catch (IOException hiba)
            {
                Console.Error.WriteLine("Fájlhiba: " + hiba.Message);
                Environment.ExitCode = 1;
            }
            catch (UnauthorizedAccessException hiba)
            {
                Console.Error.WriteLine("A fájl nem érhető el: " + hiba.Message);
                Environment.ExitCode = 1;
            }
            finally
            {
                Bezar();
            }
        }
    }
}